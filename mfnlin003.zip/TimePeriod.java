
public class TimePeriod { 
         /* 
           *A TimePeriod is a Duration range.It has an inclusive lower bound ,I, and exclusive upper bound , u .
           *A Duration, d, falls within the range if l<= d < u.
         */
   private Duration l;
   private Duration u;
         
         
         /*
           *Create a TimePeriod with the given inclusive lower bound and exclusive upper bound.
         */
           
   public TimePeriod(Duration lowerBound, Duration upperBound){
      this.l=lowerBound;
      this.u=upperBound;
   }
         
         /*
           *Obtain the lower bound for this time period.      
         */
   public Duration lowerBound(){
               
      return this.l;
   }
          /*
           *Obtain the upper bound for this time period.      
         */
   public Duration upperBound(){
      return this.u;
   }
         
         /*
          * Determine whether the given duration falls within this time period i.e. whether
          * lowerBound()<=duration<upperBound().
          */
         
   public boolean includes(Duration duration){
      if ((this.l).compareTo(duration)<=0){
         if((this.u).compareTo(duration)>0){
            return true;
         }
         return false;          
      }
      return false;      
   }   
             
             
          /* 
           *Determine whether this time period precedes the other time period i.e. whether this.upperBound()<=other.lowerBound().
         */   
         
   public boolean precedes(TimePeriod other){  
      if((this.u).compareTo(other.l)<=0){
         return true;
      }
      return false;
   }              
                        
                  
          /*             
           *Determine whether this time period is adjacent to the other time period i.e. whether
           * this.upperBound() is equal to other.lowerBound(), or this.lowerBound() is equal to other.upperBound()
          */
   public boolean adjacent(TimePeriod other){
      if(((this.u).compareTo(other.l)==0)|((this.l).compareTo(other.u)==0)){
         return true;
      }
      else{
         return false;
      }
   }
          
          /*
           * Obtain a String representation of this TimePeriod object in the form:
           * [<duration> .. <duration>] where durations are given as a series of non-zero quantities of time
           *  units, the smallest being minutes.                         
         */
   public String toString(){
        
      return ("["+Duration.format(lowerBound(),TimeUnit.MINUTE)+" .. "+Duration.format(upperBound(),TimeUnit.MINUTE)+"]");
   }       
               
}