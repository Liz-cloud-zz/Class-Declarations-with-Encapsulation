import java.lang.*;
import java.util.*;

public class TariffTable{
      /*
       *A TariffTable records parking tariffs for a pay-to-stay car park.
      */
   private ParkingTariff []p;
   int nextfree;
      /*
       * Create a TariffTable with the given maximum number of entries.
       */
   public TariffTable(int max){
      this.p= new ParkingTariff[max];
      nextfree=0;
   }    
       
       /*
        * Add the tariff for the given period to the table. The period must directly follow, and be adjacent to, that for the previous tariff entered.
        *If the period does not follow or is not adjacent then an IllegalArgumentException is thrown.
        */
        
   public void addTariff(TimePeriod period , Money tariff){
      TimePeriod t1;
      
      if ((nextfree<(this.p).length)&&(nextfree!=0)){
         t1=this.p[nextfree-1].getTimePeriod();
                        
         if ((t1.precedes(period))&&(t1.adjacent(period))){
            this.p[nextfree]= new ParkingTariff(period,tariff);
            nextfree=nextfree+1;  
         }
         else {
                                    
            throw new IllegalArgumentException("Tariff periods must be adjacent.");
                                    
         }
      }       
      else if (nextfree==0){
         this.p[nextfree]= new ParkingTariff(period,tariff);
         nextfree=nextfree+1;     
      }
      else {
         nextfree=nextfree+1;
      }                             
   }
   
        /*
         * Obtain the tariff for the given length of stay.
         */
        
   public Money getTariff(Duration lengthOfStay){
      TimePeriod t;
      Currency c = new Currency("R", "ZAR", 100);
      Money m=new Money(0,c);
      for(int i=0 ; i < nextfree;i++){
         if(!(this.p[i].equals(null))){
            t= this.p[i].getTimePeriod();
            if (t.includes(lengthOfStay)==true){
               m=(this.p[i].getMoney());
            }
         }    
                                 
      }
      return m;
   }
        
        /*
         *Obtain a String representation of this TariffTable in the form:
         *<period0> : <tariff0>
         *<periodn> : <tariffn>             
         */
   public String toString(){
      int len=(this.p).length;
      String p_copy="";
      for(int i=0;i < nextfree;i++){
         if(!(this.p[i].equals(null))){
            p_copy=p_copy+this.p[i].toString();
         }
                   
      }
            
      return(p_copy.trim());
                       
   }           
                               
}