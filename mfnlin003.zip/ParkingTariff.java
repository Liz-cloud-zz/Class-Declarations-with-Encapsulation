import java.lang.*; 
import java.util.*; 
public class ParkingTariff{
      /*
       *TariffTable contain a collection of ParkingTariff objects, where each ParkingTariff object stores a
       *TimePeriod and Money.
       *Your class will have instance variable(s), constructor(s), and method(s).
       * You should aim to move beyond simple get and set methods to ones that offer greater functionality.
       */
       
   private TimePeriod tp;
   private Money m ;
   
  
       
   public ParkingTariff(TimePeriod tp, Money m ){
      this.tp = tp; 
      this.m=m;                                                                                      
   }         
       
   public void setTimePeriod(TimePeriod t){
      this.tp=t;
   }
      
   public void setMoney(Money m){
      this.m=m;
   }                        
                 
       
   public Money getMoney(){
      return (this.m);
   }
       
   public TimePeriod getTimePeriod(){
      return (this.tp);
   }
       
   public String toString(){
      String output;
      output=tp.toString()+" : "+m.toString()+"\n";
      return output;
              
   }  
       
   public boolean contains(Money m , TimePeriod t){
      if((this.m).equals(m)&&( this.tp).equals(t)){
         return true;
      }
      return false;
   }
               
}
       

